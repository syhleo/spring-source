package com.tuling.dynamicproxy.intf;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by smlz on 2020/3/31.
 */
@Configuration
@ComponentScan(basePackages = {"com.tuling.dynamicproxy.intf"})
public class MainCofig {
}
