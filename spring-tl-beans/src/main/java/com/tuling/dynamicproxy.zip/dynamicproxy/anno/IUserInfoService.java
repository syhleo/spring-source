package com.tuling.dynamicproxy.anno;

/**
 * Created by smlz on 2020/3/31.
 */

public interface IUserInfoService {

	void queryUserInfo(Integer userId);
}
